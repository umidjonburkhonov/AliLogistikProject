// src/components/LanguageSelector.js
import React from 'react';
import { useTranslation } from 'react-i18next';

function Language() {
    const { i18n } = useTranslation();

    const handleChange = (e) => {
        i18n.changeLanguage(e.target.value);
    };

    return (
        <select onChange={handleChange} value={i18n.language}>
            <option value="ru">Ru</option>
            <option value="en">En</option>
        </select>
    );
}

export default Language
